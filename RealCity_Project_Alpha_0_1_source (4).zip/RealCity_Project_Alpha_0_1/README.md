# RealCity Project — Alpha 0.1

Protótipo inicial Android (projeto Android Studio com WebView local).

## O que já funciona nesta alfa
- Editor 2D em grade com ferramentas para ruas, casas, árvores e pontos de ônibus.
- Ferramenta de seleção e movimentação básica de objetos.
- Importação de imagens PNG para o projeto.
- Campo para registrar a cidade de inspiração.
- Seleção de qualidade (alta/média/baixa/PNG) como configuração inicial.
- Prévia isométrica simples.
- Salvar localmente no dispositivo e exportar o projeto em JSON.

## Limitações importantes
- Esta é uma alfa de protótipo, não um editor 3D completo.
- A visualização por satélite está identificada na interface, mas ainda não conectada a um provedor de mapas.
- Não há geração automática por IA nesta versão.
- O JSON exportado não é um mapa Proton Bus. A exportação para o formato real do jogo depende de documentação/estrutura de mapa compatível e testes.
- A qualidade escolhida ainda não converte modelos 3D; nesta alfa ela altera apenas alguns aspectos visuais do protótipo.

## Como gerar o APK
1. Abra esta pasta no Android Studio (versão recente).
2. Aguarde a sincronização do Gradle.
3. Se solicitado, instale Android SDK 35 e a versão de Gradle indicada pelo Android Studio.
4. Use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. O APK de depuração ficará em `app/build/outputs/apk/debug/app-debug.apk`.

Aplicativo mínimo Android 6.0+ (minSdk 23). Requer conexão com internet apenas para futuras funções online; o editor local funciona offline.
